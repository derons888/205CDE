insert into Goods values (1,'Iphone10',9000,'Iphone10 ','Apple','Iphone Series','Mobile Phone','IOS 13.4','Red/Blue/White','iphone.jpg', '128/256/512GB');
insert into Goods values (2,'Iphone SE 2020',4500,'Iphone SE 2020 ','Apple','Iphone Series','Mobile Phone','IOS 13','Red/Blue/White','iphonese.jpg', '64/128/256GB');
insert into Goods values (3,'Iphone 6',5500,'Iphone 6 ','Apple','Iphone Series','Mobile Phone','IOS 12','Red/Blue/White','iphone6.jpg', '64/128/256GB');
insert into Goods values (4,'Samsung Galaxy S20',6500,'Samsung Galaxy S20 ','Samsung','S20 Series','Mobile Phone','Android 11','Blue/White/Gold','s20.jpg', '64/128/256/512GB');
insert into Goods values (5,'Samsung Galaxy Flip',12000,'Samsung Galaxy Flip ','Samsung','Galaxy Flip Series','Mobile Phone','Android 11','Black/White','flip.jpg', '64/128/256GB');
insert into Goods values (6,'Samsung Galaxy Note 10',7500,'Samsung Galaxy Note 10','Samsung','Samsung','Mobile Phone','Android 10','Red/Blue/White','note10.jpg', '64/128/256GB');
insert into Goods values (7,'Huawei P40',8600,'Huawei P40 ','Huawei','Huawei P Series','Mobile Phone','Android 10','Red/Blue/White/Pink','p40.jpg', '64/128/256/512GB');
insert into Goods values (8,'Huawei Mate XS',10000,'Huawei Mate XS ','Huawei','Huawei Mate Series','Mobile Phone','Android 10','Red/Blue/White','xs.jpg', '64/128/256GB');
insert into Goods values (9,'Huawei Nova 7i',4000,'Huawei Nova 7i','Huawei','Huawei Nova Series','Mobile Phone','Android 10','Red/Blue/White','nova7i.jpg', '64/128/256GB');
