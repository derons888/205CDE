from flask_script import Manager
# obtain info from views.py and instruct manager.py
from app.views import app
from db import dbhelper



manager = Manager(app)


# Execute dbhelper createtablesfunction
# @manager.command to invoke flask script act as cmd commands
@manager.command
def create_tables():
    dbhelper.create_tables()

# Execute dbhelper to insert store data into the database
@manager.command
def load_data():
    dbhelper.load_data()


if __name__ == '__main__':
    manager.run()
