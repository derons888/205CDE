# Enable Flask Debug Mode
DEBUG = True
# Set SQL DBMS Path
SQLALCHEMY_DATABASE_URI = 'sqlite:///../db/database.db'
# Enable SQL Output
SQLALCHEMY_ECHO = True
# Flask Secret key
SECRET_KEY = 'enydM2ANhdcoKwdVa0jWvEsbPFuQpMjf'